// Layla Darwiche 
// ADS103 
// Assignment 3
#pragma once
#include <iostream>
#include <cstdlib>
#include <vector>
#include <fstream>
#include <iterator>
#include "Node.h"

using namespace std;

class BinaryMaxHeap{

	public:
		// creating the heap 
		vector<Node> heap; 
		fstream Q2OutputFile; 

		// tree functions 
		int leftChildIndex(int parent); 
		int rightChildIndex(int parent);
		int parentIndex(int child);

		// for inserting in correct order 
		void heapifyUp(int index); 

		// inserts numbers
		void Insert(Node numb); 

		void showHeap();

};

