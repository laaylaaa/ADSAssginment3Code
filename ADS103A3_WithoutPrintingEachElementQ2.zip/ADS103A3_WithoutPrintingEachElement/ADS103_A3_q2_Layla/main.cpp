// Layla Darwiche 
// ADS103 
// Assignment 3
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include "BinaryMaxHeap.h"

using namespace std; 

// -------------- QUESTION 2 --------------

void main() {

	// classes to use input and output files 
	ifstream Q2InputFile;
	fstream Q2OutputFile;

	Q2InputFile.open("input-q2a2.txt");
	Q2OutputFile.open("output-q2a2.txt");

	// VARIABLES
	int numbersOfNumbersHeap;
	vector<int> arr;
	// creating the maxHeap for numbers to be inserted 
	BinaryMaxHeap maxHeap;

	if (Q2InputFile.is_open()) { // check if input files open 

		// get the amount of numbers that are in the array of numbers 
		Q2InputFile >> numbersOfNumbersHeap;
		cout << numbersOfNumbersHeap << endl;

		if (Q2OutputFile.is_open()) {

			for (int i = 0; i < numbersOfNumbersHeap; i++) {

				int temp;
				Q2InputFile >> temp;
				arr.push_back(temp);  // for printing to console

				// put the elements in the array into the heap
				maxHeap.Insert(Node(temp));

				Q2OutputFile << endl;
			}

			maxHeap.showHeap(); 

			// FOR CHECKING TO CONSOLE 
			for (int i = 0; i < arr.size(); i++) {

				cout << arr[i] << " ";
			}
			cout << endl;

			// if there is no file, display error in console 
			if (!Q2OutputFile.is_open()) {

				cout << "Error, there is no output txt file!";
			}
		}

		// if there is no file, display error in console 
		if (!Q2InputFile.is_open()) {

			cout << "Error, there is no input txt file!";
		}

		Q2InputFile.close();
		Q2OutputFile.close();

		system("pause");
	}
}