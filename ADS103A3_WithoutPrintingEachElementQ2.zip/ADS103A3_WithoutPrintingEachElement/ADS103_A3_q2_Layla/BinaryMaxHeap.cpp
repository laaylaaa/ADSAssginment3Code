// Layla Darwiche 
// ADS103 
// Assignment 3
#include "BinaryMaxHeap.h"

int BinaryMaxHeap::leftChildIndex(int parent){

	int leftIndex = 2 * parent + 1; // gets the left child node 

	if (leftIndex < heap.size())
		return leftIndex;
	else
		return -1; 
}

int BinaryMaxHeap::rightChildIndex(int parent){

	int rightIndex = 2 * parent + 2; // gets the right child node 

	if (rightIndex < heap.size())
		return rightIndex;
	else
		return - 1; 
}

int BinaryMaxHeap::parentIndex(int child){

	int parentInd = (child - 1) / 2; // gets the parent node 

	if (child == 0)
		return -1;
	else
		return parentInd; 
}

// compares current node to parent, and swaps the smaller to the top 
// recursive function
void BinaryMaxHeap::heapifyUp(int index){

	// If index is not the top of tree and within the heap bounds 
	// and current nodes num is more than parent nodes num 
	if (index >= 0 && parentIndex(index) >= 0 && heap[index].num > heap[parentIndex(index)].num) {

		// swap varaibles between current node and parent
		Node temp = heap[index]; // hold the original heap index
		heap[index] = heap[parentIndex(index)]; // change the heap index to the parents index
		heap[parentIndex(index)] = temp; // make parent index equal temp (original heap index)
		// run recursively on the parent
		heapifyUp(parentIndex(index)); 
	}
}


void BinaryMaxHeap::Insert(Node numb){
	 
	heap.push_back(numb); 
	heapifyUp(heap.size() - 1); 
}

void BinaryMaxHeap::showHeap(){

	Q2OutputFile.open("output-q2a2.txt");

	Q2OutputFile << "Heap --> ";

	for (Node p : heap) {

		Q2OutputFile << p.num << " "; 
	}
	Q2OutputFile << endl;
}


