// Layla Darwiche 
// ADS103 
// Assignment 3
#pragma once
#include <queue>
#include "Node.h"
#include <fstream>

// LevelNode helps with getting what level the numbers on the tree are on 
class LevelNode {
public:
	Node* num;
	int level;

	LevelNode(Node* num, int level) {

		this->num = num;
		this->level = level;
	}
};

class BST {

public:

	fstream Q1OutputFile; // used in the show function to print its level to OutputFile 
	Node* root = NULL;
	virtual void insert(Node* newNode);

	// show level
	void show(Node* p);
};

