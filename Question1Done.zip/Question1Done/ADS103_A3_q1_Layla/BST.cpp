// Layla Darwiche 
// ADS103 
// Assignment 3
#include "BST.h"


void BST::insert(Node* newNode) {

	// IF the root is null, then make the inserted number the root 
	if (root == NULL) {

		root = newNode;
		return;
	}

	// pointers to help find where to insert new number 
	Node* current = root;
	Node* parent = NULL;

	while (true) {

		// keep track of where we were 
		parent = current;

		// IF new number is less then the number at current node, then go down LEFT 
		if (newNode->num < current->num) {

			// going down left side 
			current = current->leftChild;

			// if current is NULL, we found an empty space to insert new number
			if (current == NULL) {

				parent->leftChild = newNode;
				return;
			}
		}
		else {

			// go right 
			current = current->rightChild;

			// if current is NULL, we found an empty space to insert new number
			if (current == NULL) {

				parent->rightChild = newNode;
				return;
			}
		}
	}
}


void BST::show(Node* p) {
	
	Q1OutputFile.open("output-q1a2.txt");

	// base case 
	if (root == NULL) 
		return;

	// create an empty queue for level order traversal 
	queue<LevelNode> q;

	// Enqueue Root and initialize height
	q.push(LevelNode(root, 0));

	int previousOutputLevel = -1;

	while (q.empty() == false) {

		// print front of queue and remove it from queue 
		LevelNode node = q.front();
		if (node.level != previousOutputLevel) {

			Q1OutputFile << endl; 
			Q1OutputFile << node.level << " : "; 
			previousOutputLevel = node.level;
		}

		Q1OutputFile << node.num->num << " ";
		q.pop();

		// enqueue left child 
		if (node.num->leftChild != NULL)
			q.push(LevelNode(node.num->leftChild, node.level + 1));

		// enqueue right child 
		if (node.num->rightChild != NULL)
			q.push(LevelNode(node.num->rightChild, node.level + 1));
	}
}
