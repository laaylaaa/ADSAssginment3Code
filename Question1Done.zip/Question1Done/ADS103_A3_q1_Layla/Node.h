// Layla Darwiche 
// ADS103 
// Assignment 3
#pragma once
#include <iostream>
#include <fstream>
#include <string>

using namespace std;

class Node {

public:
	// numbers to be inserted into AVL and BST
	int num;

	// point to next node in structure
	Node* leftChild;
	Node* rightChild;

	Node(int num);
};

