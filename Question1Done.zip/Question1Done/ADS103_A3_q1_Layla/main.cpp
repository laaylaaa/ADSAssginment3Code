// Layla Darwiche 
// ADS103 
// Assignment 3
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include "BST.h"
#include "AVL.h"

using namespace std;

// -------------- QUESTION 1 --------------

void main() {

	// classes to use input and output files 
	ifstream Q1InputFile;
	fstream Q1OutputFile;

	// creating the AVL, which uses functions from the BST class
	AVL avl;  

	// input and output file 
	Q1InputFile.open("input-q1a2.txt");
	Q1OutputFile.open("output-q1a2.txt"); 

	// VARIABLES	
	int numberOfNumArr;
	vector<int> arr;

	if (Q1InputFile.is_open()) { // check if input file is open

		cout << "----- DATA FROM INPUT FILE -----" << endl; 
		cout << "     ---- FOR CHECKING ---- " << endl; 

		// getting size of the array of numbers
		Q1InputFile >> numberOfNumArr;
		cout << numberOfNumArr << endl;

		if (Q1OutputFile.is_open()) {

			// set to false so we dont display rotations happening in console
			avl.displayRotations = false;

			// inputting array 
			for (int i = 0; i < numberOfNumArr; i++) {
				int temp;
				Q1InputFile >> temp;
				arr.push_back(temp); // putting in array to print to console for checking 
				// inserting numbers into AVL
				avl.AVL::insert(new Node(temp));  
			}

			avl.show(avl.root); // printing the level of the numbers in the tree

			// FOR CHECKING TO CONSOLE 
			for (int i = 0; i < arr.size(); i++) {

				cout << arr[i] << " ";
			}
			cout << endl;
		}

		// if there is no file, display error in console 
		if (!Q1OutputFile.is_open()) {

			cout << "Error, there is no output txt file!";
		}
	}

	// if there is no file, display error in console 
	if (!Q1InputFile.is_open()) {

		cout << "Error, there is no input txt file!";
	}

	Q1InputFile.close();  
	Q1OutputFile.close(); 

	system("pause");
}