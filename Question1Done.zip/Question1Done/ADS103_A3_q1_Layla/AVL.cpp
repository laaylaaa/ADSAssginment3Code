// Layla Darwiche 
// ADS103 
// Assignment 3
#include "AVL.h"

// using recursion, we keep exploring down and pass final height values up 
int AVL::height(Node* node) {

    int h = 0;

    // helps break recursion cycle when we get to nulls at the bottom of branches
    if (node != NULL) {

        int leftH = height(node->leftChild);
        int rightH = height(node->rightChild);

        // max gives the biggest of the 2 and discard the smaller
        int maxH = max(leftH, rightH);
        h = maxH + 1;
    }

    return h;
}

int AVL::difference(Node* node) {

    // if empty tree, well its balanced its 0 
    if (node == NULL)
        return 0;

    int leftH = height(node->leftChild);
    int rightH = height(node->rightChild);
    int balanceFactor = leftH - rightH;

    return balanceFactor;
}

Node* AVL::RRrotation(Node* parent) {

    Node* temp = parent->rightChild; // make temp to hold the parents right child, *so we dont overwrite and lose it 
    parent->rightChild = temp->leftChild; // make the parent of the right child to temps left 
    temp->leftChild = parent; // make temps left the new parent 

    if (displayRotations)
        cout << "RR rotation on " << parent->num << endl;

    return temp;
}

Node* AVL::LLrotation(Node* parent) {

    Node* temp = parent->leftChild; // make temp to hold left child *
    parent->leftChild = temp->rightChild; // make the parents left child equal the temps right child
    temp->rightChild = parent; // change the parent to temps right child 

    if (displayRotations)
        cout << "LL rotation on " << parent->num << endl;

    return temp;
}

// needs 2 rotations 
// first rotation rotates bottom two nodes, which turns the whole structure into a RRrotation 
// second rotation uses RRrotation 
Node* AVL::LRrotation(Node* parent) {

    Node* temp = parent->leftChild; // make temp for parents left child 
    parent->leftChild = RRrotation(temp); // do a RR rotation on the left child 

    if (displayRotations)
        cout << "LR rotation on " << parent->num << endl;

    return LLrotation(parent);
}

Node* AVL::RLrotation(Node* parent) {

    Node* temp = parent->rightChild; // make temp for parents right child
    parent->rightChild = LLrotation(temp); // do a LL rotation on the right child 

    if (displayRotations)
        cout << "RL rotation on " << parent->num << endl;

    return RRrotation(parent);
}

Node* AVL::balance(Node* parent) {

    // get balance factor 
    int balanceFactor = difference(parent);

    // IF balanceFactor not within -1, 0, 1 then work out what rotations to do 
    if (balanceFactor > 1) {

        // left BRANCH is heavy, work out  if it left or right CHILD heavy
        if (difference(parent->leftChild) > 0) {

            // left child unbalanced
            parent = LLrotation(parent);
        }
        else {

            // right child unbalanced
            parent = LRrotation(parent);
        }

    }
    else if (balanceFactor < -1) {

        // right branch is heavy, but which child 
        if (difference(parent->rightChild) > 0) {

            // left child heavy 
            parent = RLrotation(parent);
        }
        else {

            //right child heavy 
            parent = RRrotation(parent);
        }
    }

    return parent;
}

Node* AVL::insertAVL(Node* parent, Node* newStudent) {

    // if sub tree empty, this becomes the parent 
    if (parent == NULL) {

        parent = newStudent;
        return parent;
    }

    // parent not null, so we havent found empty space to stick new student yet 
    // so we need to go down left or right path 
    if (newStudent->num < parent->num) {

        parent->leftChild = insertAVL(parent->leftChild, newStudent);
        parent = balance(parent);
    }
    else { // assume ID is >= parents ID

        parent->rightChild = insertAVL(parent->rightChild, newStudent);
        parent = balance(parent);
    }
}

void AVL::insert(Node* newStudent) {

   // cout << "Inserting " << newStudent->num << endl;
    root = insertAVL(root, newStudent);
   // cout << endl;
}
