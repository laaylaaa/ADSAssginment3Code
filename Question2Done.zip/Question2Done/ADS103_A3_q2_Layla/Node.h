// Layla Darwiche 
// ADS103 
// Assignment 3
#pragma once
#include <iostream>
#include <string>

using namespace std;

class Node{

	public: 

		int num; 

		Node(int num); 
};

