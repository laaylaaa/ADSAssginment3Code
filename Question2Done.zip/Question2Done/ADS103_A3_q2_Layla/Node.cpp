// Layla Darwiche 
// ADS103 
// Assignment 3
#include "Node.h"

Node::Node(int num){

	this->num = num; 
}
